

// ''
// ""
// ``



// array in javascript

superHero = ["SuperMan", "Hulk", "Cap America", "Thor", "Black panther" , true, 31]

// console.log(typeof(superHero));
console.log(`my super hero :   ${superHero[1]}`);




