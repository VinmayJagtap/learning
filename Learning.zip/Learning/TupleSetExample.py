# List and Tuple ---- duplicate allowed


# set - duplicate not allowed
# un-ordered
# unchangeable
# once set created -- you can not change its item..........but we can add new item.

superHero = ["SuperMan", "Hulk", "Cap America", "Thor", "Black panther" , "Hulk"]
superHero1 = ("SuperMan", "Hulk", "Cap America", "Thor", "Black panther" , "Hulk")
superHero2 = {"SuperMan", "Hulk", "Cap America", "Thor", "Black panther" , "Hulk"}

# print(type(superHero))
# print(type(superHero1))


# superHero2 = tuple(("SuperMan", "Hulk", "Cap America", "Thor", "Black panther" , "Hulk"))
# print(type(superHero1))



# Tuple example

print(superHero)
print(superHero1)
print(superHero2)




# set example 
print('===========================================')

for x in superHero2:

    if('Thor' in x):
        print( 'match found')
    
    print(x)

#Add Item to Set

print ('======Add Item to Set================')

print(superHero2)

superHero2.add("IronMan")

print(superHero2)