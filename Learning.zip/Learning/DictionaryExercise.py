

x={
    "browserName" : "Chrome",
    "CreatedBy" : "google",
    "latestVersion": 119
}
print(x)
item = x.popitem()

print(x)
print(item)




