package cucumber.test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinition {

	WebDriver driver;

@Given("User Launch Chrome browser")
public void user_Launch_Chrome_browser() {
   driver = new ChromeDriver();
}

@When("User opens URL {string}")
public void user_opens_URL(String npmapplication) {
	
	driver.get(npmapplication);
    
}

@When("User enters Email as {string} and Password as {string}")
public void user_enters_Email_as_and_Password_as(String email, String password) throws Exception {
   
	System.out.println("email : "+email+" and Password : "+password);
	Thread.sleep(3000);
	
//	driver.findElement(By.className("email valid")).clear();
//	driver.findElement(By.className("email valid")).sendKeys(email);
//	
//	driver.findElement(By.className("password valid")).clear();
//	driver.findElement(By.className("password valid")).sendKeys(password);
	
	
	
	
	driver.findElement(By.cssSelector(".email")).clear();
	driver.findElement(By.cssSelector(".email")).sendKeys(email);
	
	driver.findElement(By.cssSelector("input#Password")).clear();;
	driver.findElement(By.cssSelector("input#Password")).sendKeys(password);
	
	
}

@When("Click on Login")
public void click_on_Login() {
   
	driver.findElement(By.tagName("button")).click();
	
}

@Then("Page Title should be {string}")
public void page_Title_should_be(String expectedtitle) {
	
	Assert.assertEquals(driver.getTitle(), expectedtitle);
    
}

@When("User click on Log out link")
public void user_click_on_Log_out_link() {
	
	driver.findElement(By.linkText("Logout")).click();
   
}

@Then("close browser")
public void close_browser() throws InterruptedException {
    Thread.sleep(5000);
	driver.quit();
}


}
