 #Loop in python

superHero = ["SuperMan", "Hulk", "Cap America", "Thor", "Black panther"]

for ibm_avenger in superHero:

    if("Thor" in ibm_avenger):
        print(ibm_avenger)

    else:
        print("avenger is "+ibm_avenger)
    




  #====================================================================
  #
  #   
superHero = ["SuperMan", "Hulk", "Cap America", "Thor", "Black panther"]
i=0

while i< len(superHero):

    print(f"item into Suprthero listing at {i} is {superHero[i]}")
    i =  i + 1


