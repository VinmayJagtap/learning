#indexed
#changeable

superHero = ["SuperMan", "Hulk", "Cap America", "Thor", "Black panther" ]



#--------- access value from list--------
print(f'------access value from list------')
print(superHero[4])



# change the value into list
print(f'------change the value into list------')
print(superHero)
superHero[4] = "Iron Man"
print(superHero)


# change the value into list ----- with range
print(f'------change the value into list ----- with range------')
superHero = ["SuperMan", "Hulk", "Cap America", "Thor", "Black panther" ]
print(superHero)
superHero[1:4] = ["ironMan", "AntMan"]
print(superHero)



# add an item
print(f'---------add an item using extend keyword-----------')

superHero = ["SuperMan", "Hulk", "Cap America", "Thor", "Black panther" ]

avenger = ["Ironman", "Ant Man"]
avenger2 = ("Ironman", "Ant Man")
avenger3 = {"Ironman", "Ant Man"}

print(superHero)
superHero.extend(avenger)
print(superHero)

# add an item
print(f'---------add an item using append keyword-----------')

superHero = ["SuperMan", "Hulk", "Cap America", "Thor", "Black panther"]
print(superHero)
superHero.append("IronMan")
print(superHero)
superHero = ["SuperMan", "Hulk", "Cap America", "Thor", "Black panther"]
superHero.append(avenger)
print(superHero)
superHero = ["SuperMan", "Hulk", "Cap America", "Thor", "Black panther"]
superHero.append(avenger2)
print(superHero)
superHero = ["SuperMan", "Hulk", "Cap America", "Thor", "Black panther"]
superHero.append(avenger3)
print(superHero)

print(f'=====================================================')
superHero = ["SuperMan", "Hulk", "Cap America", "Thor", "Black panther"]
superHero.append(avenger)
print(superHero)
print(f'=====================================================')

# ['SuperMan', 'Hulk', 'Cap America', 'Thor', 'Black panther', ['Ironman', 'Ant Man']]
# x = ['Ironman', 'Ant Man']
# print(x[0])
print(superHero[-1][-1])


