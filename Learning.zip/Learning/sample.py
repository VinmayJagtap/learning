name = 'Vinmay'
print( 'Hello Everyone '+name)