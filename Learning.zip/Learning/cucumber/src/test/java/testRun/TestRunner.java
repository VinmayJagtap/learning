package testRun;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

//import io.cucumber.testng.AbstractTestNGCucumberTests;
//import io.cucumber.testng.CucumberOptions;

//import org.testng.annotations.DataProvider;
//
//import io.cucumber.java.Scenario;
//import io.cucumber.testng.AbstractTestNGCucumberTests;
//import io.cucumber.testng.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
					features = ".\\FeatureFiles\\logintest.feature",
					glue = "cucumber.test",
					plugin = { "pretty",
								"html:target/ibmCucumberreport.html"
							},
					tags = "@Sanity"
					
			

			)


public class TestRunner  {	
		
//	@DataProvider	
//	public Object[][] Scenario() {
//		
//		return super.scenarios();
	}
	
	
	

