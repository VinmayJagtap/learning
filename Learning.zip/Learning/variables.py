
IBM_Name = "Vinmay"
EMP_ID = "01234"

print("Welcome "+ IBM_Name+" " +EMP_ID)