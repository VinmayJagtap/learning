# Create Tuple
# Ordered/indexed
# Unchangable - once it is created then we cannot change values of tuple(immutable)

browser_tuple = ("Chrome","edge","S afari")

print(type(browser_tuple))


#Access value of tuple

print(browser_tuple[0])
print(len(browser_tuple))

#how to add value to tuple

#tuple to list conversion
browser_list= list(browser_tuple)
print(type(browser_list))

#adding value to list
browser_list.append("Firefox")
print(browser_list)

#converting list to tuple
thistuple = tuple(browser_list)
print(type(thistuple))
print(thistuple)


#for loop example

for br in thistuple:
    print(br)

for x in range(len(thistuple)):
    print(f"value of index {x} is {thistuple[x]}")



#while loop example
i=0

while i<(len(thistuple)):
    print(thistuple[i])
    i = i+1