superHero = ["SuperMan", "Hulk", "Cap America", "Thor", "Black panther"]



# validate "Hulk" into superhero list or not 

isHulkPresent = "IronMan" in superHero


# print(f'verify item into list or not : {"Ant Man" in superHero}')
print(isHulkPresent)


if(isHulkPresent):
    print('found the match !!')
    print("=============inside if condition===============")
else:
    print(f'I am inside else condition......')

print("=============outside if condition===============")
