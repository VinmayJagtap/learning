package basic;

public class LoopExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int x = 10;
		
		for(int i =0;i <=x;i++) {
			
			System.out.println("Line of code1 : "+i);
		}
	}

}
