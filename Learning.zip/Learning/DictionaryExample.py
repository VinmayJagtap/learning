#dictionary in python
ibm_browser =   {

                "browserName" : "chrome",
                "createdBy": "Google",
                "latestVersion": 119,
                "old_version": [118, 117, 116, 115],
                "is_win_supported" : True

            }

#access values of diuctionary
print(ibm_browser["latestVersion"])

#keys from dictionary
x_keys = ibm_browser.keys()
print(x_keys)

#add new item to 
print(ibm_browser)
ibm_browser["browserDescriptiopn"]="description details"
print(ibm_browser)

#change Item to dictionary

print(ibm_browser)
ibm_browser["latestVersion"]=121
print(ibm_browser)

#changeitem to dictiuonary using update keyword
print(ibm_browser)
ibm_browser.update({"latestVersion":123})
print(ibm_browser)


