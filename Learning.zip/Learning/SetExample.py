# Set Example 
# set items are unordered, unchangeable and do not allow duplicate values
# note: once set is created, you can not change the items, but you can add or remove items

# Create a set 

browser_set = set(("chrome", "edge", "safari"))

browser = {"chrome", "edge", "safari", 'firefox', "edge"}

print(type(browser_set))

print(type(browser))

print(browser)   #------ {'chrome', 'edge', 'firefox', 'safari'}

# Conditional check True
#conditional check False
is_edge_browser_exit = "opera" in browser

print(is_edge_browser_exit)

# access value from set 
for x in browser:
    print(x)

# add an item to set 

print('------------add an item to set----------------')

print(browser)

browser.add("opera")

print(browser)

# remove an item to set 

print('------------remove an item to set----------------')

print(browser)

browser.remove("opera")

print(browser)

# loop example in set 
for x in browser:
    print(x)