
# list example in python 
# indexing  - start from 0 in any prog 



#               0           1        2            3             4
#                                    -3             -2            -1
superHero = ["SuperMan", "Hulk", "Cap America", "Thor", "Black panther" , True, 31]


print(type(superHero))

# print(superHero)

# print(superHero[0])

# ele_count = len(superHero)
# print("element in superHero are: ")
# print(ele_count)

# print(superHero[   ele_count  - 3        ])

# print(superHero[-2])


# print(f'my super hero :  + {superHero[-1]}')



#=============================using constructor========================================

superHero1 = list(("hulk", "Sp. Man", "Iron Man"))

print(type(superHero1))
print(superHero1[-1])